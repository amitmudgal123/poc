class AccessKeys {
    constructor() {
        this.accountName = "demostrgac";
        this.accessKey = "sKKMVzWHBcerW4r5dQijAu88xE9gJFzrRc9CAWeqJhdaUi4RoZ4/4QDuMKkt4/lnoksFTjuKYx/KHX0zK6sjGw==";
        this.t2kInprogress = "t2kinprogress";
        this.t2kError = "t2kerror";
        this.t2kDiscarded = "t2kdiscarded";
        this.t2kCompleted = "t2kcompleted";
    }
}

module.exports = AccessKeys;
