//1. use the required packages for the application 
const tableStore = require('azure-storage');
const express = require('express');
const bodyParser = require('body-parser');
const cors=require("cors");
//2. read access keys
const authStore = require('./keys');
const authObject = new authStore();
//3. create an instance of express
const instance = express();
// 4. add the middlewares
instance.use(bodyParser.json());
instance.use(bodyParser.urlencoded({ extended: false }));

instance.use((req,res,next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'OPTIONS,GET,PUT,POST,DELETE');
    res.header('Access-Control-Allow-Headers','Origin, X-Requested-With, Content-Type, Accept, x-client-key, x-client-token, x-client-secret, Authorization');
    res.header('Access-Control-Allow-Credentials', 'true');
    next();
  })

const allowedOrigins=[
    'capacitor://localhost',
    'ionic://localhost',
    'http://localhost',
    'http://localhost:4200',
    'chrome-extension://fhbjgbiflinjbdggehcddcbncdddomop'
];

var corsOptionsDelegate = function (req, callback) {
    var corsOptions;
    if (allowedOrigins.indexOf(req.header('Origin')) !== -1) {
      corsOptions = { origin: true } // reflect (enable) the requested origin in the CORS response
    } else {
      corsOptions = { origin: false } // disable CORS for this request
    }
    callback(null, corsOptions) // callback expects two parameters: error and options
}

//5. the table client
const tableClient = tableStore.createTableService(authObject.accountName, authObject.accessKey);

async function getTableData(tableName) {
    let values = [];

    return new Promise((resolve, reject) => {
        //6a. execute the query based
        tableClient.queryEntities(tableName, null, null, (error, result, resp) => {
            if (error) {
                console.log(`"${tableName}" Error Occured in table creation ${error.message}`);
                reject('ERROR');
            } else {
                let keys = Object.keys(resp.body.value);
                console.log('=======================');
                // console.log(keys);
                keys.forEach((key, index) => {
                    console.log(`${key}: ${resp.body.value[key].RowKey}`);
                    let row = {
                        "PartitionKey": resp.body.value[key].PartitionKey,
                        "RowKey": resp.body.value[key].RowKey
                    };
                    values.push(row);
                });
                console.log('Length: ' + values.length);
                resolve(values);
                console.log('=======================');
            }
        });
    })
}

//6. retrive records from table based on PartitionKey
instance.get('/api/v1/summary', cors(corsOptionsDelegate), async(request, response) => {
    // let values = await getTableData(authObject.t2kInprogress);
    // console.log(values);
    let sumData = "";
    let dta = await summary().then(resp => {
        console.log('xxxx: '+ resp);
        sumData = resp;
    })
    response.json({statusCode: 200, data: sumData});
});

//7. retrive records from table based on PartitionKey
instance.get('/api/v1/details', cors(corsOptionsDelegate), async(request, response) => {
    // let values = await getTableData(authObject.t2kInprogress);
    // console.log(values);
    let sumData = "";
    let dta = await details().then(resp => {
        console.log('xxxx: '+ resp);
        sumData = resp;
    })
    response.json({statusCode: 200, data: sumData});
});

//8. retrive records from table based on PartitionKey
instance.post('/api/v1/add_record', cors(corsOptionsDelegate), (req, response) => {
   
    let res = "";
    if(!Object.keys(req.body).length) {
        response.json({statusCode: 400, message: "Missing required fields."});
    } else if(!req.body.tableName) {
        response.json({statusCode: 400, message: "{tableName} required."});
    }  else if(!req.body.tenantName) {
        response.json({statusCode: 400, message: "{tenantName} required."});
    }  else if(!req.body.fileName) {
        response.json({statusCode: 400, message: "{fileName} required."});
    } else {
        // not empty then insert the record
        let record = {
            PartitionKey: req.body.tenantName,
            RowKey: req.body.fileName
        }
        console.log(record);
        
        tableClient.insertEntity(req.body.tableName, record, (error, result) => {
            if (error) {
                response.json({ statusCode: 500, message: `Error Occured during entity insertion ${error.message}`});
            } else {
                response.json({ statusCode: 200, message: 'Record added successfully.', data: JSON.stringify(result) });
            }
        });
    }
});

async function summary() {
  
    sumData = await getData();
    let summary = {
        "inprogress": sumData.inprogress.length,
        "error": sumData.error.length,
        "discarded": sumData.discarded.length,
        "completed": sumData.completed.length,
    };

    return JSON.stringify(summary);
};

async function details() {
  
    ddData = await getData();
    let respData = {
        "inprogress": ddData.inprogress,
        "error": ddData.error,
        "discarded": ddData.discarded,
        "completed": ddData.completed,
    };

    return JSON.stringify(respData);
};

async function getData() {
    let inprogress = [];
    let error = [];
    let discarded = [];
    let completed = [];
    
    // Get inprogress data
    await getTableData(authObject.t2kInprogress).then(value => {
        console.log('Ingp resp:' + value);
        inprogress = value;
    }).catch(error => {
        console.log('t2kInprogress Error:' + error);
    })

    // Get error data
    await getTableData(authObject.t2kError).then(value => {
        console.log('Error resp:' + value);
        error = value;
    }).catch(error => {
        console.log('t2kError:' + error);
    })

    // Get discarded data
    await getTableData(authObject.t2kDiscarded).then(value => {
        console.log('discarded resp:' + value);
        discarded = value;
    }).catch(error => {
        console.log('t2kDiscarded Error:' + error);
    })

    // Get completed data
    await getTableData(authObject.t2kCompleted).then(value => {
        console.log('completed resp:' + value);
        completed = value;
    }).catch(error => {
        console.log('t2kCompleted Error:' + error);
    })

    let storageData = {
        "inprogress": inprogress,
        "error": error,
        "discarded": discarded,
        "completed": completed,
    }

    return storageData;
}

instance.listen(8009, () => {
  console.log('Server Started on port 8009');
});


