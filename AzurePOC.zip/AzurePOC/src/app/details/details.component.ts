
import { Component, OnInit,ViewChild, Output, EventEmitter, Input} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {GetApiService} from '../get-api.service';
@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
    details:any;
    files:any;
    inprogress:any;
    error:any;
    discarded:any;
    completed:any;
    label:string;
    constructor(private api :GetApiService, private router: Router, private activatedRoute : ActivatedRoute) {
      this.label = '';
      router.events.subscribe((val) => {
          // see also
    this.activatedRoute.params.subscribe(params => {
      this.label = params['label'];
      console.log("label",this.label);
  });
      });
    }
  @Input() lb:any;
  ngOnChanges(changes: any): void {
    debugger
    //this.childProperty = changes

  }
  ngOnInit(): void {

    this.api.getDetails().subscribe((data) => {
      this.details = data;
      let Data = JSON.parse(this.details.data);
      this.files=Data;
      this.inprogress=this.files.inprogress;
      console.log("inprogress---",this.inprogress);

      this.error=this.files.error;
      console.log("error---",this.error);

      this.discarded=this.files.discarded;
      console.log("discarded---",this.discarded);

      this.completed=this.files.completed;
      console.log("completed---",this.completed);

      console.log(this.files.inprogress[0].PartitionKey);

    })
  }

}
