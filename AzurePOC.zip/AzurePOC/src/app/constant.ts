export class AppConstant {
  public static accountName: string = "demostrgac";
  public static accessKey: string = "sKKMVzWHBcerW4r5dQijAu88xE9gJFzrRc9CAWeqJhdaUi4RoZ4/4QDuMKkt4/lnoksFTjuKYx/KHX0zK6sjGw==";
  public static t2kInprogress: string = "t2kinprogess";
  public static t2kError: string = "t2kerror";
  public static t2kDiscarded: string = "t2kdiscarded";
  public static t2kCompleted: string = "t2kcompleted";
}
