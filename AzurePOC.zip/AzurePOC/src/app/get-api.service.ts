import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormBuilder, FormGroup } from "@angular/forms";
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GetApiService {
  form:any= FormGroup;
  constructor(
    private http: HttpClient
  ) { }

  getSummary() {
    return this.http.get('http://localhost:8009/api/v1/summary');
  }
  getDetails() {
    return this.http.get('http://localhost:8009/api/v1/details');
  }
  addRecord(data:any) {
    /* var formData: any = new FormData();
      formData.append("tableName", this.form.get('tableName').value);
      formData.append("tenantName", this.form.get('tenantName').value);
      formData.append("fileName", this.form.get('fileName').value); */
    const requestHeaders = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post('http://localhost:8009/api/v1/add_record',data,{ headers: requestHeaders });
   //return this.http.post('http://localhost:8009/api/v1/add_record',body ,{ headers: header }).map((data: Response) => data.json() );
   }


}
