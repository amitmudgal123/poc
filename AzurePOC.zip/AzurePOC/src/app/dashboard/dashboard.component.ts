import { Component, OnInit,ViewChild, Output, EventEmitter, Inject} from '@angular/core';
import * as Chart from 'chart.js';
import {GetApiService} from '../get-api.service';
import { FormBuilder, FormGroup, FormControl } from "@angular/forms";
import { DetailsComponent } from '../details/details.component';
import { NavigationExtras, Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  summary: any;
  labels: any;
  data: any;
  show:boolean=true;
  parentProperty :boolean = false;
  @Output() clickElement = new EventEmitter();
  display=false;
  constructor(public router: Router, private api:GetApiService){
    console.log(router);
    console.log();
    if(this.router.url == '/dashboard'){
      this.parentProperty = false
    }
    else{
      this.parentProperty = true
    }
   // Nothing to do
  }

  ngOnInit() {
    this.api.getSummary().subscribe((data) => {
      console.log(data);
      this.summary = data;
      let summaryData = JSON.parse(this.summary.data);
      this.labels = Object.keys(summaryData);
      this.data = Object.values(summaryData);
      console.log("labels are", this.labels);
      console.log("data are", this.data);
      console.warn("get api data", this.summary);
      console.log(Object.keys(this.summary.data));
      console.log(Object.values(this.summary.data));
      this.chart();
    })

  }
  canvas: any;
  ctx: any;
  newChart:any;
  @ViewChild('mychart') mychart: any;

  chart() {

    this.canvas = this.mychart.nativeElement;
    this.ctx = this.canvas.getContext('2d');

    this.newChart = new Chart(this.ctx, {
      type: 'pie',

      data: {
        labels: this.labels,
        datasets: [{
          label: 'Summary',
          data: this.data,
          backgroundColor: [
            'rgb(54, 162, 235)',
            'rgb(220,20,60)',
            'rgb(128,0,0)',
            'rgb(0,128,0)'
          ]
        }]
      }
    });
  }

  navigateToDetails(event:any){
    let chartData = this.newChart.getElementsAtEvent(event)
    let chart:any = chartData[0]._chart;
    let lb = chart.data.labels[chartData[0]._index];
    console.log(lb);

    this.router.navigate(['dashboard/details', lb]);
    this.parentProperty = true;

  }

}
